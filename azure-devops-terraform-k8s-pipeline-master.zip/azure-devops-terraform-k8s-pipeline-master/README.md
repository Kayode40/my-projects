This code is used to demostrate the implementation of DevOps using Azure DevOps Pipeline, Terraform, Docker registry and Kubernetes. A simple python hello api is deployed in the Kubernetes cluster using AzurePipeline  and the backend Kubernetes cluster is created using Terraform.

API URL :- SERVER:5000/hello

Sample Output :- Hello XXXXXXXXXX, Current time is 30-06-2020 01:01:01


 Azure Marketplace TerraformCLI plugins:-
 
Terraform 1 (https://marketplace.visualstudio.com/items?itemName=ms-devlabs.custom-terraform-tasks)

Terraform 2 (https://marketplace.visualstudio.com/items?itemName=charleszipp.azure-pipelines-tasks-terraform)


Detail implementation is given in following video:-

https://youtu.be/U5Ti0LjxvLE

https://youtu.be/e0kSNSN6idE
